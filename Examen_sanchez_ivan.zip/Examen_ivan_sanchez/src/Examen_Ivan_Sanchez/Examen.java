package Examen_Ivan_Sanchez;

public class Examen {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Ejercicios.ejer1();
		//System.out.println("El numero " + Ejercicios.ejer2(5, 6, 2) + " es el mayor");
		
		//Ejercicios.ejer3(4);
		
		//Ejercicios.ejer4(2);
		//Ejercicios.ejer5();
		//Ejercicios.ejer6("Hola me llamo ivan");
		//Ejercicios.ejer7("ivan sanchez guillen");
		//Ejercicios.ejer8("ivan");
		Ejercicios.mostrarMenu();
	}

}
